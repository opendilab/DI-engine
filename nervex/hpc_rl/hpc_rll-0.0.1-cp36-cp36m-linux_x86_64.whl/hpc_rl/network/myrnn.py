"""
Copyright 2020 Sensetime X-lab. All Rights Reserved

Main Function:
    1. build LSTM: you can use build_LSTM to build the lstm module
"""
import math

import torch
import torch.nn as nn
import numpy as np

import ln

def layernorm_forward(x, gamma, beta):
    """
    Forward pass for layer normalization.

    During both training and test-time, the incoming data is normalized per data-point,
    before being scaled by gamma and beta parameters identical to that of batch normalization.
    
    Note that in contrast to batch normalization, the behavior during train and test-time for
    layer normalization are identical, and we do not need to keep track of running averages
    of any sort.

    Input:
    - x: Data of shape (N, D)
    - gamma: Scale parameter of shape (D,)
    - beta: Shift paremeter of shape (D,)
    - ln_param: Dictionary with the following keys:
        - eps: Constant for numeric stability

    Returns a tuple of:
    - out: of shape (N, D)
    - cache: A tuple of values needed in the backward pass
    """
    out, cache = None, None
    eps = 1e-5
    ###########################################################################
    # TODO: Implement the training-time forward pass for layer norm.          #
    # Normalize the incoming data, and scale and  shift the normalized data   #
    #  using gamma and beta.                                                  #
    # HINT: this can be done by slightly modifying your training-time         #
    # implementation of  batch normalization, and inserting a line or two of  #
    # well-placed code. In particular, can you think of any matrix            #
    # transformations you could perform, that would enable you to copy over   #
    # the batch norm code and leave it almost unchanged?                      #
    ###########################################################################
    N,D= x.shape
    x_mean = np.mean(x,axis=1).reshape(N,1)
    x_var = np.var(x,axis=1).reshape(N,1)
    #print("x_mean: " + str(x_mean))
    #print("x_var: " + str(x_var))
    #print("eps: " + str(eps))
    #print("3 / sqrt(2): " + str(1 / np.sqrt(x_var)))

    xmu = x-x_mean
    x_rstd = 1 / np.sqrt(x_var+eps)

    out = gamma * xmu * x_rstd + beta
    #cache = (x, xmu, x_rstd)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    #return out, cache
    return out, x_mean, x_rstd


#def layernorm_backward(dout, cache):
def layernorm_backward(dout, x, x_mean, x_rstd, gamma):
    """
    Backward pass for layer normalization.

    For this implementation, you can heavily rely on the work you've done already
    for batch normalization.

    Inputs:
    - dout: Upstream derivatives, of shape (N, D)
    - cache: Variable of intermediates from layernorm_forward.

    Returns a tuple of:
    - dx: Gradient with respect to inputs x, of shape (N, D)
    - dgamma: Gradient with respect to scale parameter gamma, of shape (D,)
    - dbeta: Gradient with respect to shift parameter beta, of shape (D,)
    """
    dx = None
    ###########################################################################
    # TODO: Implement the backward pass for layer norm.                       #
    #                                                                         #
    # HINT: this can be done by slightly modifying your training-time         #
    # implementation of batch normalization. The hints to the forward pass    #
    # still apply!                                                            #
    ###########################################################################
    #(x, x_mean, x_rstd, gamma) = cache
    N,D= x.shape

    #print("x: " + str(x))
    #print("x_mean: " + str(x_mean))
    #print("x_rstd: " + str(x_rstd))
    #print("gamma: " + str(gamma))

    x_mu = x - x_mean
    xivar = x_rstd
    dgamma = np.sum(dout*x_mu*x_rstd,axis=0,keepdims=True)
    dbeta = np.sum(dout,axis=0,keepdims=True)

    #print(dout.shape)
    #print(x.shape)
    #print(x_mu.shape)
    #print(xivar.shape)
    #print(gamma.shape)
    #print(dgamma.shape)
    #print(dbeta.shape)

    ds = np.sum(dout*x*gamma,axis=1,keepdims=True)
    db = np.sum(dout*gamma,axis=1,keepdims=True)
    #print(ds.shape)
    #print(db.shape)
    scale = 1.0 / D
    a = x_rstd
    b = (db * x_mean - ds) * a * a * a * scale;
    c = -b * x_mean - db * a * scale
    dx = a * dout * gamma + b * x + c
    #print(a.shape)
    #print(b.shape)
    #print(c.shape)
    #print(dx.shape)
    #print("x_mu: " + str(x_mu))
    #print("ds: " + str(ds))
    #print("db: " + str(db))
    #print("scale: " + str(scale))
    #print("a: " + str(a))
    #print("b: " + str(b))
    #print("c: " + str(c))
    #print("dx: " + str(dx))

    #dlxhat = dout * gamma
    #dxhatx = xivar
    #dlvar = -0.5*np.sum(gamma * x_mu*(xivar**3)*dout,axis=1,keepdims=True)
    #dlvarx = 2*x_mu/D
    #dlmu = -1.*np.sum(dlxhat*xivar,axis=1,keepdims=True)-2.*np.sum(dlvar*x_mu,axis=1,keepdims=True)/D
    #dx = dlxhat*dxhatx + dlvar*dlvarx + dlmu/D
    #print("tmp0: " + str(dlxhat*dxhatx))
    #print("tmp1: " + str(dlvar*dlvarx))
    #print("tmp2: " + str(dlmu/D))
    #print("dx:" + str(dx))
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx, dgamma, dbeta


class LNFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, gamma, beta, x_mean, x_rstd, y):
        #ln.ln_forward(x, x_mean, x_rstd, y)
        y, x_mean, x_rstd = layernorm_forward(x.cpu().detach().numpy(), gamma.cpu().detach().numpy(), beta.cpu().detach().numpy())
        
        variables = [x, torch.from_numpy(x_mean), torch.from_numpy(x_rstd), gamma]
        ctx.save_for_backward(*variables)
        return torch.from_numpy(y)

    @staticmethod
    def backward(ctx, dy):
        x = ctx.saved_variables[0]
        x_mean = ctx.saved_variables[1]
        x_rstd = ctx.saved_variables[2]
        gamma = ctx.saved_variables[3]
        dx = torch.zeros_like(x)
        dgamma = torch.zeros_like(gamma)
        dbeta = torch.zeros_like(gamma)
        #print("nmgrady: " + str(dy))
        #ln.ln_backward(x, x_mean, x_rstd, dy, dx)
        dx, dgamma, dbeta = layernorm_backward(dy.cpu().numpy(), x.cpu().detach().numpy(), x_mean.cpu().numpy(), x_rstd.cpu().numpy(), gamma.cpu().detach().numpy())
        dx = torch.from_numpy(dx)
        dgamma = torch.from_numpy(dgamma)
        dbeta = torch.from_numpy(dbeta)
        #print("nmgradx: " + str(dx))
        return dx, dgamma, dbeta, None, None, None

class MYLNFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, gamma, beta, x_mean, x_rstd, y):
        #print(gamma)
        #print(beta)
        ln.ln_forward(x, gamma, beta, x_mean, x_rstd, y)
        variables = [x, x_mean, x_rstd, gamma, beta]
        ctx.save_for_backward(*variables)
        return y

    @staticmethod
    def backward(ctx, grady):
        x = ctx.saved_variables[0]
        x_mean = ctx.saved_variables[1]
        x_rstd = ctx.saved_variables[2]
        gamma = ctx.saved_variables[3]
        beta = ctx.saved_variables[4]
        gradx = torch.zeros_like(grady)
        dgamma = torch.zeros_like(gamma)
        dbeta = torch.zeros_like(beta)
        #print("mygrady: " + str(grady))
        ln.ln_backward(grady, x, x_mean, x_rstd, gamma, dgamma, dbeta, gradx)
        #print("mygradx: " + str(gradx))
        return gradx, dgamma, dbeta, None, None, None

class LN(nn.Module):
    def __init__(self, M, N):
        super(LN, self).__init__()
        self.M = M
        self.N = N
        self.gamma = nn.Parameter(torch.ones(1, N))
        self.beta = nn.Parameter(torch.zeros(1, N))
        self.x_mean = torch.zeros(M, 1)
        self.x_rstd = torch.zeros(M, 1)
        self.y = torch.zeros(M, N)

    def forward(self, x):
        return LNFunction.apply(x, self.gamma, self.beta, self.x_mean, self.x_rstd, self.y)


class MYLN(nn.Module):
    def __init__(self, M, N):
        super(MYLN, self).__init__()
        self.M = M
        self.N = N
        self.x_mean = torch.zeros(M, 1)
        self.x_rstd = torch.zeros(M, 1)
        self.y = torch.zeros(M, N)
        self.gamma = nn.Parameter(torch.ones(N))
        self.beta = nn.Parameter(torch.zeros(N))

    def forward(self, x):
        return MYLNFunction.apply(x, self.gamma, self.beta, self.x_mean, self.x_rstd, self.y)

