from kornia.augmentation._2d.mix.cutmix import RandomCutMix
from kornia.augmentation._2d.mix.mixup import RandomMixUp
